# SnugWin 增量更新包 (e1ce70d → 345cc8e)

## 包信息
- **基线版本**: e1ce70d93d00d4d13696bb0d79c1d6db09a07612
- **目标版本**: 345cc8efbae99a06e9cbbb273349ccd44cf3026b (诊断版本)
- **包大小**: ~1.5 MB (vs 完整包 72.6 MB)
- **来源**: 从artifact 14932171630提取核心变更文件

## 变更文件清单
1. **SnugWin.Windows.dll** - 包含完整诊断日志（TargetPath等）
2. **SnugWin.Core.dll** - 依赖重建
3. **SnugWin.App.dll** - 依赖重建
4. **SnugWin.App.exe** - 依赖重建

**注意**: 其他481个运行时文件（.NET runtime, 语言包等）**完全相同**，无需更新。

## 前置条件验证

### 确认当前版本为 e1ce70d
检查原安装目录中的 `README-TEST.txt`，应包含：
```
Commit: e1ce70d93d00d4d13696bb0d79c1d6db09a07612
```

如果不是此版本，**请勿应用此增量包**，改为下载完整包。

### 验证基线文件哈希（可选但推荐）
在原安装目录执行：
```powershell
Get-FileHash SnugWin.Windows.dll -Algorithm SHA256
# 应为基线哈希（见下方"预期变化"）
```

## 应用步骤

### 1. 备份原文件
```powershell
# 在原安装目录
Copy-Item SnugWin.*.dll,SnugWin.App.exe backup\ -Force
```

### 2. 停止运行中的程序
- 右键托盘图标退出 SnugWin
- 或任务管理器结束 SnugWin.App.exe

### 3. 覆盖更新文件
将本增量包中的4个文件复制到原安装目录，覆盖同名文件：
- SnugWin.Windows.dll
- SnugWin.Core.dll
- SnugWin.App.dll
- SnugWin.App.exe

### 4. 验证更新完整性
```powershell
# 在安装目录
Get-FileHash SnugWin.Windows.dll,SnugWin.Core.dll,SnugWin.App.dll,SnugWin.App.exe -Algorithm SHA256 | Format-Table

# 对比本包中的 PATCH-SHA256.txt
```

### 5. 启动程序
- 右键 SnugWin.App.exe → 以管理员身份运行
- 验证启动正常

## 预期变化

### 文件哈希对比

**更新前（e1ce70d基线）**:
```
需要用户提供或从原完整包获取
```

**更新后（345cc8e目标）**:
```
见 PATCH-SHA256.txt
```

### 功能变化
- **新增**: `[诊断]` 标记的完整身份日志
- **新增**: TargetPath记录（StableId计算关键）
- **不变**: 所有安全检查和容错机制
- **不变**: driver目录、配置文件、其他运行时

## 回滚步骤

如遇问题需回滚到 e1ce70d：
1. 停止 SnugWin.App.exe
2. 从 `backup\` 恢复4个原文件
3. 或重新安装 e1ce70d 完整包

## 验证测试

更新后复现UU重连场景：
1. 启动 UU GameViewer 连接手机
2. 启动 SnugWin（管理员）
3. 等待初次建屏成功
4. **断开 UU 连接**
5. **重新连接 UU**（触发诊断）
6. 收集日志中所有 `[诊断]` 开头的行

## 技术说明

### 为何仅4个文件
代码变更仅在 `src/SnugWin.Windows/Display/PhoneDisplayService.cs`：
- 新增50行诊断日志代码
- SnugWin.Windows.dll 直接包含此文件
- 其他3个文件因依赖传递需要重建

### 运行时文件不变
.NET 10运行时、语言包、第三方依赖DLL等481个文件：
- e1ce70d和345cc8e使用相同SDK版本（10.0.404）
- 相同publish参数（win-x64, self-contained）
- 文件完全相同，哈希一致

### 安全性
- 文件来自sanctioned GitHub Actions artifact 14932171630
- 完整SHA256校验
- 可独立验证与完整包的对应文件哈希一致

## 故障排查

### 更新后无法启动
- 检查是否以管理员身份运行
- 验证哈希是否匹配
- 恢复备份文件

### 诊断日志未出现
- 确认版本正确：日志应包含 `[诊断]` 前缀
- 检查日志文件位置

### 仍然报"主显示器脱离"
- 这是**预期行为**：增量包仅添加诊断，不修复问题
- 目标是收集 `[诊断]` 日志以确认根因

---

**状态**: 增量更新包，用于解决完整包下载EOF问题  
**目标**: 收集真机诊断日志，确认StableId变化根因
